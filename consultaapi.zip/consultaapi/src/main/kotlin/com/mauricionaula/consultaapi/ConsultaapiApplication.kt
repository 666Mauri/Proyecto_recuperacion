package com.mauricionaula.consultaapi

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class ConsultaapiApplication

fun main(args: Array<String>) {
	runApplication<ConsultaapiApplication>(*args)
}
