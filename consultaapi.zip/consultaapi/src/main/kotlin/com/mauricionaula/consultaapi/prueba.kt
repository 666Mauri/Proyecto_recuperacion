package com.mauricionaula.consultaapi

class prueba {
}